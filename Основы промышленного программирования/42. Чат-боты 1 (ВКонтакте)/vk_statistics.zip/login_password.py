import os

LOGIN = os.getenv("LOGIN")
PASSWORD = os.getenv("PASSWORD")